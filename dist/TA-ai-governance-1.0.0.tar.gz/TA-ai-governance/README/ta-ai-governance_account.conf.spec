[<name>]
anthropic_admin_key = 
anthropic_analytics_key = 
google_client_id = 
google_client_secret = 
google_customer_id = 
google_refresh_token = 
ms_client_id = 
ms_client_secret = 
ms_tenant_id = 
openai_admin_key = 
provider = 
proxy_url = 
sh_allow_http = 
sh_api_key = 
sh_base_url = 
sh_server_type = 
