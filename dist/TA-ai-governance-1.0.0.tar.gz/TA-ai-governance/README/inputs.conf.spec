[anthropic_compliance://<name>]
account = Select an account with provider Anthropic.
backfill_days = Days of history to collect on first run (max 180). (Default: 7)
collect_directory = Also snapshot organization users and groups each cycle (at most once per 12 hours). (Default: true)
index = (Default: default)
interval = Polling interval in seconds. (Default: 300)
max_events_per_cycle = (Default: 2000)
python.required = {3.7|3.9|3.13}
* For Python scripts only, selects which Python version to use.
* Set to "3.9" to use the Python 3.9 version.
* Set to "3.13" to use the Python 3.13 version.
* Optional.
* Default: not set

[anthropic_analytics://<name>]
account = Select an account with provider Anthropic.
collect_cost = (Default: true)
collect_summaries = (Default: true)
collect_usage = (Default: true)
index = (Default: default)
interval = Polling interval in seconds. Analytics data is finalized daily. (Default: 86400)
lookback_days = Re-collect this many trailing days each cycle to pick up late-arriving data. (Default: 7)
python.required = {3.7|3.9|3.13}
* For Python scripts only, selects which Python version to use.
* Set to "3.9" to use the Python 3.9 version.
* Set to "3.13" to use the Python 3.13 version.
* Optional.
* Default: not set

[openai_audit://<name>]
account = Select an account with provider OpenAI.
backfill_days = Days of history to collect on first run. (Default: 7)
collect_users = Also snapshot organization users each cycle (at most once per 12 hours). (Default: true)
index = (Default: default)
interval = Polling interval in seconds. (Default: 300)
max_events_per_cycle = (Default: 2000)
python.required = {3.7|3.9|3.13}
* For Python scripts only, selects which Python version to use.
* Set to "3.9" to use the Python 3.9 version.
* Set to "3.13" to use the Python 3.13 version.
* Optional.
* Default: not set

[openai_usage://<name>]
account = Select an account with provider OpenAI.
bucket_width = (Default: 1d)
collect_costs = (Default: true)
collect_usage = (Default: true)
index = (Default: default)
interval = (Default: 86400)
lookback_days = Re-collect this many trailing days each cycle to pick up late-arriving data. (Default: 7)
python.required = {3.7|3.9|3.13}
* For Python scripts only, selects which Python version to use.
* Set to "3.9" to use the Python 3.9 version.
* Set to "3.13" to use the Python 3.13 version.
* Optional.
* Default: not set

[gemini_audit://<name>]
account = Select an account with provider Google Gemini.
applications = Comma-separated Admin SDK Reports applicationName values to collect. (Default: gemini_in_workspace_apps)
backfill_days = Days of history to collect on first run (Reports API retains up to 180 days). (Default: 7)
index = (Default: default)
interval = (Default: 600)
max_events_per_cycle = (Default: 5000)
python.required = {3.7|3.9|3.13}
* For Python scripts only, selects which Python version to use.
* Set to "3.9" to use the Python 3.9 version.
* Set to "3.13" to use the Python 3.13 version.
* Optional.
* Default: not set

[copilot_audit://<name>]
account = Select an account with provider Microsoft 365 Copilot.
backfill_days = (Default: 7)
index = (Default: default)
interval = Audit log queries are asynchronous on the Microsoft side; each cycle either submits a new query or retrieves finished results. (Default: 900)
record_types = Comma-separated Microsoft Purview audit record types to collect. (Default: copilotInteraction)
python.required = {3.7|3.9|3.13}
* For Python scripts only, selects which Python version to use.
* Set to "3.9" to use the Python 3.9 version.
* Set to "3.13" to use the Python 3.13 version.
* Optional.
* Default: not set

[copilot_usage://<name>]
account = Select an account with provider Microsoft 365 Copilot.
index = (Default: default)
interval = (Default: 86400)
period = (Default: D7)
python.required = {3.7|3.9|3.13}
* For Python scripts only, selects which Python version to use.
* Set to "3.9" to use the Python 3.9 version.
* Set to "3.13" to use the Python 3.13 version.
* Optional.
* Default: not set

[selfhosted_monitor://<name>]
account = Select an account with provider Self-hosted / Open-source.
collect_metrics = Scrape the metrics endpoint (vLLM / LiteLLM). Ignored for server types without Prometheus metrics. (Default: true)
collect_models = Snapshot served models each cycle and emit model_added / model_removed audit events on changes. (Default: true)
collect_runtime = For Ollama servers, also collect currently loaded/running models (/api/ps). (Default: true)
index = (Default: default)
interval = Polling interval in seconds. (Default: 300)
metrics_path = (Default: /metrics)
metrics_prefixes = Comma-separated prefixes of Prometheus metric families to ingest. (Default: vllm:,litellm_,ollama_)
python.required = {3.7|3.9|3.13}
* For Python scripts only, selects which Python version to use.
* Set to "3.9" to use the Python 3.9 version.
* Set to "3.13" to use the Python 3.13 version.
* Optional.
* Default: not set
